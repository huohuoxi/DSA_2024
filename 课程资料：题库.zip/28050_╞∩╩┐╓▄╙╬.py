class Vertex:
    def __init__(self, num):
        self.key = num
        self.connectedTo = {}
        self.color = 'white'
    def add_neighbor(self, nbr, weight=0):
        self.connectedTo[nbr] = weight
    def get_neighbors(self):
        return self.connectedTo.keys()

def graph(n):
    step = ((1,-2),(2,-1),(1,2),(2,1),\
        (-1,-2),(-2,-1),(-1,2),(-2,1))
    for i in range(n):
        for j in range(n):
            for k in step:
                if (0 <= (i + k[0]) <= (n-1))and(0 <= (j + k[1]) <= (n-1)):
                    adj[i][j].add_neighbor(adj[i + k[0]][j + k[1]])

def dfs(u, step):
    u.color = "gray"
    if step >= n*n-1:
        return True
    neighbors = ordered_by_avail(u)
    for k in neighbors:
        if (k.color == "white") and (dfs(k, step+1)):
            return True
    else:
        u.color = "white"
        return False

def ordered_by_avail(n):   # important：随时看邻居中未访问节点最多的
    res_list = []
    for v in n.get_neighbors():
        if v.color == "white":
            c = 0
            for w in v.get_neighbors():
                if w.color == "white":
                    c += 1
            res_list.append((c,v))
    res_list.sort(key = lambda x: x[0])
    return [y[1] for y in res_list]



n = int(input())
success = False
adj = [[Vertex(1) for i in range(n)] for i in range(n)]
graph(n)

xi, yi = map(int,input().split())
#print('loading')
if dfs(adj[xi][yi], 0):
    print('success')
else:
    print('fail')
