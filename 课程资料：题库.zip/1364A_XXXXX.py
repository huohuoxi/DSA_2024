t=int(input())
for i in range(t):
    find=False
    n,x=map(int,input().split())
    s=list(map(int,input().split()))
    sumi=sum(s)
    a=0
    b=0
    if sumi%x!=0:
        find=True
        print(n)
        continue
    else:
        for j in range(n-1):
            sumi=sumi-s[j]
            if sumi%x!=0:
                a=(n-j-1)
                find=True
                break
        sumi=sum(s)
        for j in range(n-1):
            sumi=sumi-s[n-j-1]
            if sumi%x!=0:
                b=(n-j-1)
                find=True
                break
    if find:
        if a<b:
            print(b)
        else:
            print(a)
    else:
        print(-1)