t,m=map(int,input().split())
kusakusuri=[]
dp=[[0]*(t+1) for i in range(m)]
for i in range(m):
    kusakusuri.append(list(map(int,input().split())))
for j in range(t+1):
    if kusakusuri[0][0]<=j:
            dp[0][j]=kusakusuri[0][1]
for i in range(1,m):
    for j in range(1,t+1):
        if kusakusuri[i][0]>j:
            dp[i][j]=dp[i-1][j]
        else:
            dp[i][j]=max(dp[i-1][j],dp[i-1][j-kusakusuri[i][0]]+kusakusuri[i][1])
print(dp[m-1][t])