# 双端队列实现
from collections import deque
n, k = map(int,input().split())
s = list(map(int,input().split()))
s = [[i,s[i]] for i in range(len(s))]
ans = []
win = s[:k]
win = sorted(win, reverse = True, key = lambda x: x[1])
win = deque(win)
ans.append(win[0][1])
for i in range(1, n-k+1):
    try:
        while s[i+k-1][1] > win[-1][1]:
            win.pop()
    except:
        pass
    win.append(s[i+k-1])
    while win[0][0] < i:
        win.popleft()
    ans.append(win[0][1])
print(' '.join(map(str,ans)))