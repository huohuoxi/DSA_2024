from collections import deque
t = int(input())
for _ in range(t):
    n = int(input())
    s = deque([])
    for i in range(n):
        type, num = map(int, input().split())
        if type == 1:
            s.append(num)
        else:
            if num == 0:
                s.popleft()
            else:
                s.pop()
    if len(s)==0:
        print('NULL')
    else:
        
        print(' '.join(map(str,s)))