while True:
    try:
        s=input()
    except EOFError:
        break
    stack=[]
    right=[]
    for i,k in enumerate(s):
        if k=='(':
            stack.append(i)
        if k==')':
            if len(stack)>0:
                stack.pop()
            else:
                right.append(i)
    ans=[' ' for i in range(len(s))]
    for i in stack:
        ans[i]='$'
    for i in right:
        ans[i]='?'
    print(s)
    print(''.join(ans))