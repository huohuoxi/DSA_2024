def find(x):
    if parent[x] == x:
        return x
    else:
        parent[x] = find(parent[x])
        return find(parent[x])

def union(x, y):
    parent[find(x)] = find(y)

t = int(input())
for i in range(t):
    n, m = map(int,input().split())
    parent = [i for i in range(2*n+1)]
    for _ in range(m):
        cata, a, b = input().split()
        a = int(a)
        b = int(b)
        if cata == 'D':
            try:
                union(a, b+n)
                union(b, a+n)
            except:
                pass
        else:
            try:
                if find(a) == find(b+n) or find(b) == find(a+n):
                    print('In different gangs.')
                elif find(a) == find(b) or find(a+n) == find(b+n):
                    print('In the same gang.')
                else:
                    print('Not sure yet.')
            except:
                print('Not sure yet.')