import math
n, m = map(int,input().split())
adj = [[] for i in range(n+1)]
vis = [False for i in range(n+1)]
ans = [math.inf for i in range(n+1)]
def dfs(k, i):
    ans[k] = min(ans[k], i)
    vis[k] = True
    for j in adj[k]:
        if not vis[j]:
            dfs(j, i)
for i in range(m):
    u, v = map(int,input().split())
    adj[v].append(u)
for i in range(1, n+1):
    dfs(i, i)
ans = ans[1:]
print(*ans)