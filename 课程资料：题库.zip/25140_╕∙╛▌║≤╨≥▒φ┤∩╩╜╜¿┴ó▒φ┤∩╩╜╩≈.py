class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def bfs(node):
    ans.append(node.value)
    if node.right:
        queue.append(node.right)
    if node.left:
        queue.append(node.left)
    if queue:
        bfs(queue.pop(0))
n = int(input())
for _ in range(n):
    stack = []
    queue = []
    ans = []
    s = input()
    for i in s:
        node = Node(i)
        if i.isupper():
            node.left = stack.pop()
            node.right = stack.pop()
        stack.append(node)
    bfs(stack[0])
    print(''.join(reversed(ans)))