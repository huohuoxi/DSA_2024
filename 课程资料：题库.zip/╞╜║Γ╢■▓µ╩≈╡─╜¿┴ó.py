class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
        self.height = 1

class AVL:
    def __init__(self):
        self.root = None

    def _get_height(self, node):
        if not node:
            return 0
        return node.height

    def _get_balance(self, node):
        if not node:
            return 0
        return self._get_height(node.left) - self._get_height(node.right)
    
    def _rotate_left(self, node):
        right = node.right
        right_left = right.left
        right.left = node
        node.right = right_left
        node.height = 1 + max(self._get_height(node.left), self._get_height(node.right))
        right.height = 1 + max(self._get_height(right.left), self._get_height(right.right))
        return right
    
    def _rotate_right(self, node):
        left = node.left
        left_right = left.right
        left.right = node
        node.left = left_right
        node.height = 1 + max(self._get_height(node.left), self._get_height(node.right))
        left.height = 1 + max(self._get_height(left.left), self._get_height(left.right))
        return left

    def _insert(self, value, parent):
        if not parent:
            return Node(value)
        else:
            if value < parent.value:
                parent.left = self._insert(value, parent.left)
            else:
                parent.right = self._insert(value, parent.right)
        
        parent.height = 1 + max(self._get_height(parent.left), self._get_height(parent.right))
        
        balance = self._get_balance(parent)
        if balance > 1:
             if value < parent.left.value:
                 return self._rotate_right(parent)
             else:
                 parent.left = self._rotate_left(parent.left)
                 return self._rotate_right(parent)
        if balance < -1:
            if value > parent.right.value:
                return self._rotate_left(parent)
            else:
                parent.right = self._rotate_right(parent.right)
                return self._rotate_left(parent)
        
        return parent

    def insert(self, value):
        self.root = self._insert(value, self.root)
    
def walk(node):
    if not node:
        return
    ans.append(node.value)
    if node.left:
        walk(node.left)
    if node.right:
        walk(node.right)        

n = int(input())
s = list(map(int,input().split()))

tree = AVL()
for k in s:
    tree.insert(k)
ans = []
walk(tree.root)
print(' '.join(map(str,ans)))