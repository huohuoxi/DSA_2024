def calive(lef, rig):
    sorted_s = []
    i = j = 0
    ive_ = 0
    lf = len(lef)
    rf = len(rig)
    while (i < lf) and (j < rf):
        if lef[i] <= rig[j]:
            sorted_s.append(lef[i])
            i += 1
        else:
            sorted_s.append(rig[j])
            j += 1
            ive_ += lf - i
    sorted_s += lef[i:]
    sorted_s += rig[j:]
    return ive_, sorted_s


def msort(s):
    if len(s) <= 1:
        return 0, s
    mid = len(s) // 2
    ive_lef, lef = msort(s[:mid])
    ive_rig, rig = msort(s[mid:])
    ive, sorted_s = calive(lef, rig)
    return ive_lef + ive_rig + ive, sorted_s


while True:
    n = int(input())
    if n == 0:
        break
    s = []
    for i in range(n):
        s.append(int(input()))
    inv, s = msort(s)
    print(inv)