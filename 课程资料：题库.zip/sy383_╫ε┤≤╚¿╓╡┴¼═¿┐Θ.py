maxstep = 0
def dfs(k):
    global maxstep
    maxstep += weight[k]
    v[k] = True
    for l in adj[k]:
        if not(v[l]):
            dfs(l)

n, m = map(int,input().split())
weight = list(map(int,input().split()))
adj = [[] for i in range(n)]
s = [0]*n
for i in range(m):
    u, v = map(int,input().split())
    adj[u].append(v)
    adj[v].append(u)
max_maxstep = 0
v = [False for _ in range(n)]
for i in range(n):
    if not(v[i]):
        maxstep = 0
        dfs(i)
        max_maxstep = max(max_maxstep, maxstep)
print(max_maxstep)