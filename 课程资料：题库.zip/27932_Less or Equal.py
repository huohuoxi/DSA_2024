n, k = map(int,input().split())
s = list(map(int,input().split()))
s = sorted(s)
if k!= 0:
    x = s[k-1]
else:
    x = 1
count = 0
for i in s:
    if i <= x:
        count +=1
    else:
        break
if k == count:
    print(x)
else:
    print(-1)
