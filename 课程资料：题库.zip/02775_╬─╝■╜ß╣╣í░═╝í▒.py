class Node:
    def __init__(self, value):
        self.file = []
        self.dir = []
        self.value = value

def take(n):
    return n.value


def see(node,layer):
    for k in node.dir:
        print('|     '*layer+k.value)
        see(k,layer+1)
    node.file = sorted(node.file, key=take)
    for k in node.file:
        print('|     '*(layer-1)+k.value)
        

count = 0
while 1:
    count = count + 1
    l = []
    while 1:
        c = input()
        if c == '*' or c == '#':
            break
        l.append(c)
    if c == '#':
        break
    root = Node('ROOT')
    father = [root]
    for k in l:
        if k[0] == 'd':
            node = Node(k)
            father[-1].dir.append(node)
            father.append(node)
        elif k[0] == 'f':
            node = Node(k)
            father[-1].file.append(node)
        else:
            father.pop()
    if count != 1:
        print()
    print('DATA SET %d:'%count)
    print('ROOT')
    see(root,1)