def convert(l):
    stack=[]
    ans=[]
    signal={'*':2,'/':2,'+':1,'-':1,'(':0}
    for token in l:
        if not(token in sig):
            ans.append(token)
        else:
            if token==')':
                for i in range(len(stack)):
                    p=stack.pop()
                    if p=='(':
                        break
                    else:
                        ans.append(p)
            else:
                if token=='(':
                    stack.append(token)
                else:
                    for i in range(len(stack)):
                        if signal[token]<=signal[stack[-1]]:
                            p=stack.pop()
                            ans.append(p)
                        else:
                            break
                    stack.append(token)
    for i in range(len(stack)):
        ans.append(stack.pop())
    return(ans)
sig='+-*/()'
n=int(input())
for i in range(n):
    l=[]
    s=input()
    token=''
    for k in s:
        if not(k in sig):
            token+=k
        else:
            if token!='':
                l.append(token)
            l.append(k)
            token=''
    if token!='':
        l.append(token)
    print(' '.join(convert(l)))