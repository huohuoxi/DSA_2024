import bisect
nums = [3, 2, 4]
"""
:type nums: List[int]
:type target: int
:rtype: List[int]
"""
target = 6
lennums = len(nums)
no = [i for i in range(lennums)]
binum = list(zip(nums, no))
binum = sorted(binum, key = lambda x:x[0])
nums = [i[0] for i in binum]
    
for i, k in enumerate(nums):
    n = target - k
    if n <= k:
        t = bisect.bisect_left(nums, n, 0, i)
        if (nums[t] == n) and (t!=i):
            print([binum[i][1], binum[t][1]])
    else:
        t = bisect.bisect_left(nums, n, i+1)
        if nums[t] == n:
            print([binum[i][1], binum[t][1]])
