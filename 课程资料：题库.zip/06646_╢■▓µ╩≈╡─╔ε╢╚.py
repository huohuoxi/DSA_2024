class TreeNode:
    def __init__(self):
        self.left = None
        self.right = None

def height(this):
    if this is None:
        return 0
    return max(height(this.left),height(this.right)) + 1
n = int(input())
nodes = [TreeNode() for i in range(n)]
for i in range(n):
    left, right = map(int,input().split())
    if left != -1:
        nodes[i].left = nodes[left - 1]
    if right != -1:
        nodes[i].right = nodes[right - 1]
print(height(nodes[0]))
    