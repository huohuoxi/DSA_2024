def mid(s):
    if len(s)%2==1:
        s=sorted(s)
        return(s[round((len(s)-1)/2)])
    else:
        s=sorted(s)
        return((s[round((len(s))/2-1)]+s[round((len(s))/2)])/2)
n=int(input())
pairs = [i[1:-1] for i in input().split()]
distances = [sum(map(int,i.split(','))) for i in pairs]
price=list(map(int,input().split()))
xjb=[]
for i in range(n):
    xjb.append(distances[i]/price[i])
mid_xjb=mid(xjb)
mid_price=mid(price)
count=0
for i in range(n):
    if (xjb[i]>mid_xjb)and(price[i]<mid(price)):
        count+=1
print(count)