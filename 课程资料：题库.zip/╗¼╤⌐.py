r, c = map(int,input().split())
zone = []
ans = [[0 for _ in range(c)] for i in range(r)]
def dfs(x, y):
    flag = False
    steps = ((1,0),(-1,0),(0,1),(0,-1))
    for i in range(4):
        newx = steps[i][0] + x
        newy = steps[i][1] + y
        if (0<= newx <= (r-1))and(0<= newy <= (c-1)):
            if (zone[newx][newy] < zone[x][y]):
                flag = True
                if ans[newx][newy] != 0:
                    ans[x][y] = max(ans[x][y], ans[newx][newy] + 1)
                else:
                    ans[x][y] = max(ans[x][y], dfs(newx, newy) + 1)
    if flag == False:
        ans[x][y] = 1
        return 1
    else:
        return ans[x][y]
for i in range(r):
    zone.append(list(map(int,input().split())))

maxans = 0
for i in range(r):
    for j in range(c):
        maxans = max(maxans, dfs(i, j))
        
print(maxans)