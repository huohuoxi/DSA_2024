# pylint: skip-file
class Node():
    def __init__(self, value) -> None:
        self.value = value
        self.left = None
        self.right = None
        self.parent = None

def build(node):
    global l
    global flag
    try:
        if node.value != '#':
            #print(node.value)
            node.left = Node(s[l])
            l += 1
            if node.left.value != '#':
                build(node.left)
            node.right = Node(s[l])
            l += 1
            if node.right.value != '#':
                build(node.right)
        else:
            pass
    except:
        flag = False
    
def pre(node):
    ans.append(node.value)
    if node.left:
        pre(node.left)
    if node.right:
        pre(node.right)        
        
while 1:
    flag = True
    n = int(input())
    if n == 0:
        break
    s = input().split()
    if s[0]!='#':
        root = Node(s[0])
        l = 1
        build(root)
        if flag == True:
            ans= []
            pre(root)
            if ans != s:
                flag = False
    else:
        flag = False

    print(['F','T'][flag])
