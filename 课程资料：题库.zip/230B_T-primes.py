tprime=[]
n = 10**6+1  # 代求的范围中的最大值
k = 0
ss = [True for i in range(n)]  # 首先默认所有数都是质数

for i in range(2,n):
    if ss[i]:  # 判断是否为质数，如果没有被标记过，就是质数
        k+=1
        tprime.append(i*i)
        for j in range(i+i,n,i):   # 将是指数的倍数的数都改为False
            ss[j] = False
tprime=set(tprime)
n=int(input())
s=list(map(int,input().split()))
for i in range(n):
    if s[i] in tprime:
        print('YES')
    else:
        print('NO')