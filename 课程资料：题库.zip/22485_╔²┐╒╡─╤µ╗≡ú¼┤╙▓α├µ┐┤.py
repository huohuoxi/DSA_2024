from collections import deque
class Node:
    def __init__(self, value) -> None:
        self.value = value
        self.left = None
        self.right = None
        self.h = None
        self.father = None
        pass

squeue = deque()
globalh = 0
globalh_node = 1
ans = []

def bfs():
    node = s[1]
    while 1:
        global globalh
        global globalh_node
        if (node.h == None):
            node.h = node.father.h + 1
        if node.h != globalh:
            ans.append(globalh_node)
        globalh = node.h
        globalh_node = node.value
        if node.left:
            squeue.append(node.left)
        if node.right:
            squeue.append(node.right)      
        if squeue:
            node = (squeue.popleft())
        else:
            break
n = int(input())
s = {i:Node(i) for i in range(1,n + 1)}

for j in range(1, n + 1):
    l, r = map(int,input().split())
    if l != -1:
        s[j].left = s[l]
        s[l].father = s[j]
    if r != -1:
        s[j].right = s[r]
        s[r].father = s[j]
s[1].h = 0
bfs()
ans.append(globalh_node)
print(*ans)