import heapq
t = int(input())
for _ in range(t):
    ans = []
    s = list(map(int,input().split()))
    small = [-s[0]]
    heapq.heapify(small)
    big = []
    heapq.heapify(big)
    ans.append(-small[0])
    for i in range(1, len(s) - 1, 2):
        a = s[i]
        b = s[i + 1]
        mid = -small[0]
        if a < mid:
            heapq.heappush(small, -a)
        else:
            heapq.heappush(big, a)
        if b < mid:
            heapq.heappush(small, -b)
        else:
            heapq.heappush(big, b)
        if len(small) > (len(big) + 1):
            temp = -heapq.heappop(small)
            heapq.heappush(big, temp)
        elif len(small) < (len(big) + 1):
            temp = -heapq.heappop(big)
            heapq.heappush(small, temp)
        ans.append(-small[0])
    print(len(ans))
    print(' '.join(map(str, ans)))