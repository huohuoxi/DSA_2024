def take(l):
    return l[1]
n=int(input())
s=[]
dic={}
name=[]
for i in range(n):
    s=input().split('-')
    try:
        dic[s[0]].append(s[1])
    except:
        dic[s[0]]=[]
        name.append(s[0])
        dic[s[0]].append(s[1])
name=sorted(name)
for k in name:
    p=dic[k]
    p_mount=[]
    for j in p:
        p_mount.append([j,(float(j[:-1])*[1,1000][j[-1]=='B'])])
    p_mount=sorted(p_mount,key=take)
    p_final=[]
    for j in p_mount:
        p_final.append(j[0])
    print(k+': '+', '.join(p_final))