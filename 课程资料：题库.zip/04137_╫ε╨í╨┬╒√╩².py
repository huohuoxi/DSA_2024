def find(n, k):
    if (len(n) < 1)or(k < 1):
        return
    smallest = 10
    for i, l in enumerate(n):
        if smallest > l:
            smallest = l
            num = i
    ans.append(n[num])
    find(n[(num+1):], k - 1)
t = int(input())
for i in range(t):
    ans = []
    n, k = input().split()
    k = int(k)
    n = list(map(int,list(n)))
    find(n, len(n) - k)
    print(''.join(map(str,ans)))