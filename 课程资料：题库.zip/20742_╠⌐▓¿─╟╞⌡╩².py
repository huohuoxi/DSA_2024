f=[0]*100
f[0]=1
f[1]=1
f[2]=2
n=int(input())
for i in range(3,n):
    f[i]=f[i-1]+f[i-2]+f[i-3]
print(f[n-1])