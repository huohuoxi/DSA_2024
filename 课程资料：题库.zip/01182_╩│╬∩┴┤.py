def find(x):
    if p[x] == x:
        return x
    else:
        p[x] = find(p[x])
        return p[x]

def union(x, y):
    p[find(x)] = find(y)

n, m = map(int,input().split())
catagory = [-1]*3
p = [i for i in range(3*n+1)]
liar = 0
for _ in range(m):
    d, x, y = map(int,input().split())
    if x > n or y > n:
        liar += 1
        continue
    if x == y and d == 2:
        liar += 1
        continue
    if d == 1:
        if find(x+n) == find(y) or find(y+n) == find(x):
            liar += 1
            continue
        else:
            union(x, y)
            union(x+n, y+n)
            union(x+2*n, y+2*n)
    else:
        if find(x) == find(y) or find(x) == find(y+n):
            liar += 1
            continue
        else:
            union(x, y+2*n)
            union(x+n, y)
            union(x+2*n, y+n)
print(liar)