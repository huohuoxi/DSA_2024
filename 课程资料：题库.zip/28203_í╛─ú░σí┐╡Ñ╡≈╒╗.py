n = int(input())
s = list(map(int, input().split()))
stack = []

f = [0]*n
for i in range(n):
    while stack and s[stack[-1]] < s[i]:
        f[stack.pop()] = i + 1
    stack.append(i)

print(*f)
