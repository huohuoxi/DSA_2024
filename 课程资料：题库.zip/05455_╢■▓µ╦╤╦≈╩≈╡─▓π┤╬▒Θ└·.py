from collections import OrderedDict
class Node():
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
def build(alist):
    if not alist:
        return None
    root = Node(alist[0])
    left = [x for x in alist if x < alist[0]]
    right = [x for x in alist if x > alist[0]]
    root.left = build(left)
    root.right = build(right)
    return root
def bfs(node):
    ans.append(node.value)
    if node.left:
       queue.append(node.left)
    if node.right:
        queue.append(node.right)
    if queue:
        bfs(queue.pop(0)) 
s = list(map(int,input().split()))
s = list(OrderedDict.fromkeys(s))
Root = build(s)
queue = []
ans = []
bfs(Root)
print(' '.join(map(str,ans)))