# import bisect
# n = int(input())
# a = []
# b = []
# c = []
# d = []
# ab = []
# cd = []
# count = 0
# for i in range(n):
#     a1, b1, c1, d1 = map(int,input().split())
#     a.append(a1)
#     b.append(b1)
#     c.append(c1)
#     d.append(d1)
# for i in a:
#     for j in b:
#         ab.append(i + j)
# ab = sorted(ab)
# for i in c:
#     for j in d:
#         num = -i - j
#         right = bisect.bisect(ab, num)
#         left = bisect.bisect_left(ab, num)
#         count += (right - left)
# print(count)

from collections import Counter
from itertools import product
n = int(input())
a = []
b = []
c = []
d = []
ab = []
cd = []
count = 0
for i in range(n):
    a1, b1, c1, d1 = map(int,input().split())
    a.append(a1)
    b.append(b1)
    c.append(c1)
    d.append(d1)

ab = Counter(map(sum,product(a, b)))
#print(ab)
for num in map(sum,product(c,d)):
        count += ab.get(-num, 0)
print(count)