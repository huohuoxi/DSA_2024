n=int(input())
for i in range(n):
    s=input().split()
    stack=[]
    for i in (s):
        if i in ["+","-","*","/"]:
            a=stack.pop()
            b=stack.pop()
            stack.append(float(eval(str(b)+i+str(a))))
        else:
            stack.append(float(i))
    print('%.2f'%stack[0])