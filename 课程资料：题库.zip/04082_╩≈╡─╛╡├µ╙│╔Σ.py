class Noden:
    def __init__(self, value):
        self.child = []
        self.value = value
        self.parent = None

class Node:
    def __init__(self, value):
        self.left = None
        self.right = None
        self.value = value
        self.parent = None

def bfs(noden):
    queue.pop(0)
    out.append(noden.value)
    if noden.child:
        for k in reversed(noden.child):
            queue.append(k)
    if queue:
        bfs(queue[0])
        

def ex(node):
    ans.append(node.value)
    if node.left:
        ex(node.left)
    if node.right:
        ex(node.right)

def reverse(node):
    if node.right == None:
        return node
    else:
        return reverse(node.parent)

def build(s, node, state):
    if not s:
        return
    if state == '0':
        new = Node(s[0][0])
        node.left = new
        new.parent = node
    else:
        pos = reverse(node.parent)
        new = Node(s[0][0])
        pos.right = new
        new.parent = pos
    build(s[1:], new, s[0][1])

def bi_to_n(node):
    if node.left:
        if node.left.value != '$':
            newn = Noden(node.left.value)
            dic[node.left] = newn
            dic[node].child.append(newn)
            newn.parent = dic[node]
            bi_to_n(node.left)
    if node.right:
        if node.right.value != '$':
            newn = Noden(node.right.value)
            dic[node.right] = newn
            dic[node].parent.child.append(newn)
            newn.parent = dic[node].parent
            bi_to_n(node.right)

n = int(input())
k = input().split()
root = Node(k[0][0])
k.pop(0)
if k:
    build(k, root, k[0][1])
ans = []
ex(root)
#print(ans)
dic = {}
dic[root] = Noden(root.value)
bi_to_n(root)
rootn = dic[root]
#print(rootn)
queue = [rootn]
out =[]
bfs(rootn)
print(' '.join(out))