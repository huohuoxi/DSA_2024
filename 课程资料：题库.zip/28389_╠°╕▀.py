from bisect import bisect_left
n = int(input())
k = list(map(int,input().split()))
k = reversed(k)
stack = []
for i in k:
    if stack:
        if i > stack[-1]:
            stack.append(i)
        else:
            pos = bisect_left(stack, i)
            stack[pos] = i
    else:
        stack.append(i)
print(len(stack))