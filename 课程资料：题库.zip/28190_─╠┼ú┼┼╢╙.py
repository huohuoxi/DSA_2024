n = int(input())
stack = []
small = [(n)]*n
big = [-1]*n
s = [0]*n
for i in range(n):
    s[i] = int(input())
for i in range(n):
    while stack and s[stack[-1]] >= s[i]:
        small[stack.pop()] = i
    stack.append(i)
stack = []
for i in range(n-1,-1,-1):
    while stack and s[stack[-1]] <= s[i]:
        big[stack.pop()] = i
    stack.append(i)
#print(*small)
#print(*big)
cow = 0
for i in range(n):
#    for j in range(i+1,small[i]):
#        if big[j] < i:
#            cow = max(cow, j - i + 1)  # 这样写答案是对的，但是需要优化否则超时
    for j in range(small[i]-1,i,-1):
        if big[j] < i:
            cow = max(cow, j - i + 1)  
            break
print(cow)