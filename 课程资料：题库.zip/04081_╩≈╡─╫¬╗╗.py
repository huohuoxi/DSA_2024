node_h = 0
class Noden:
    def __init__(self, value, height):
        self.child = []
        self.value = value
        self.parent = None
        self.height = height

class Node:
    def __init__(self, value, height):
        self.left = None
        self.right = None
        self.value = value
        self.parent = None
        self.height = height

def find(noden):
    if not dic[noden].right:
        return noden
    else:
        return find(rdic[dic[noden].right])

def convert(noden):
    global node_h
    if noden.child:
        for l in noden.child:
            l_node = Node(l.value, None)
            dic[l] = l_node
            rdic[l_node] = l
            if dic[noden].left == None:
                dic[noden].left = l_node
                l_node.parent = dic[noden]
                l_node.height = l_node.parent.height + 1
                node_h = max(node_h, l_node.height)
                convert(l)
            else:
                f = find(rdic[dic[noden].left])
                dic[f].right = l_node
                l_node.parent = dic[f]
                l_node.height = l_node.parent.height + 1
                node_h = max(node_h, l_node.height)
                convert(l)
s = input()
root = Noden(0, 0)
now = root
counter = (i for i in range(1, 10002))
noden_h = 0

dic = {}
rdic = {}
root_node = Node(0, 0)
dic[root] = root_node
rdic[root_node] = root
for k in s:
    if k == 'd':
        new = Noden(next(counter), now.height + 1)
        now.child.append(new)
        new.parent = now
        noden_h = max(noden_h, new.height)
        now = new
    else:
        now = now.parent

convert(root)
print(f'{noden_h} => {node_h}')