class Heap:
    def __init__(self) -> None:
        self.heaplist = [0]
        self.currentsize = 0
    def percUp(self, i):
        while i // 2 > 0:
            if self.heaplist[i] < self.heaplist[i // 2]:
                self.heaplist[i], self.heaplist[i // 2] = self.heaplist[i // 2], self.heaplist[i]
            i = i // 2
    def insert(self, k):
        self.heaplist.append(k)
        self.currentsize += 1
        self.percUp(self.currentsize)
    def minChild(self, i):
        if i * 2 + 1 > self.currentsize:
            return i * 2
        else:
            return [i * 2 + 1, i * 2][self.heaplist[i*2] < self.heaplist[i*2+1]]
    def percDown(self, i):
        while i * 2 <= self.currentsize:
            mc = self.minChild(i)
            if self.heaplist[i] > self.heaplist[mc]:
                self.heaplist[i], self.heaplist[mc] = self.heaplist[mc], self.heaplist[i]
            i = mc
    def delMin(self):
        retval = self.heaplist[1]
        self.heaplist[1] = self.heaplist[self.currentsize]
        self.currentsize -= 1
        self.heaplist.pop()
        self.percDown(1)
        return retval
    def buildHeap(self, alist):
        self.currentsize = len(alist)
        self.heaplist = [0] + alist[:]
        for i in range(len(alist) // 2,0,-1):
            self.percDown(i)
        

n = int(input())
heap = Heap()
for i in range(n):
    s = list(map(int,input().split()))
    if s[0] == 1:
        heap.insert(s[1])
    else:
        print(heap.delMin())