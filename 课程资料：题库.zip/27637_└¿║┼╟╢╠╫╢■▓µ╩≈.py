class Node:
    def __init__(self, value):
        self.value = value
        self.child = []

def output(node):
    ans.append(node.value)
    for i in node.child:
        output(i)

def output_mid(node):
    if len(node.child)>0:
        output_mid(node.child[0])
    ans_mid.append(node.value)
    if len(node.child)>1:
        output_mid(node.child[1])

n = int(input())
for _ in range(n):
    s = input().replace(',','')
    if len(s)==1:
        print(s)
        print(s)
    else:
        root = Node(s[0])
        fathers = []
        for i,k in enumerate(s):
            if k=='(':
                fathers.append(node)
            elif k==')':
                p = fathers.pop()
            else:
                node = Node(k)
                if fathers:
                    fathers[-1].child.append(node)

        ans = []
        ans_mid = []
        output(p)
        output_mid(p)
        print(''.join(ans).replace('*',''))
        print(''.join(ans_mid).replace('*',''))