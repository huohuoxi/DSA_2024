def dfs(x, y):
    v[x][y] = True
    movex = [0, -1, 1, 0]
    movey = [1, 0, 0, -1]
    for i in range(4):
        if (0 <= x + movex[i] <= 9)and(0 <= y + movey[i] <= 9):
            if not(v[x + movex[i]][y + movey[i]])and(s[x + movex[i]][y + movey[i]] == '.'):
                dfs(x + movex[i], y + movey[i])


    
v = [[False]*10 for _ in range(10)]
s = [0]*10
for i in range(10):
    s[i] = list(input())
num = 0

for i in range(10):
    for j in range(10):
        if s[i][j] == '.' and not(v[i][j]):
            dfs(i, j)
            num += 1
print(num)