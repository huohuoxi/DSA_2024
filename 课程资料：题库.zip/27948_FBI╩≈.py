class Node:
    def __init__(self, type):
        self.left = None
        self.right = None
        self.type = type
def con(l):
    zero = False
    one = False
    for i in l:
        if i=='0':
            zero = True
        else:
            one = True
        if zero and one:
            break
    if zero and one:
        node = Node('F')
    elif zero:
        node = Node('B')
    else:
        node = Node('I')
    left = l[:round(len(l)/2)]
    right = l[round(len(l)/2):]
    if len(l)>1:
        node.left = con(left)
        node.right = con(right)
    return node
def post(node):
    if node.left:
        post(node.left)
    if node.right:
        post(node.right)
    ans.append(node.type)
n = int(input())
s = input()
root = con(s)
ans=[]
post(root)
print(''.join(ans))