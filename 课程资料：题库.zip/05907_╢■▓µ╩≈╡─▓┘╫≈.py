from collections import defaultdict
class node:
    def __init__(self):
        self.value = None
        self.left = None
        self.right = None
        self.lparent = None
        self.rparent = None
def ask(now):
    if now.left:
        return ask(now.left)
    else:
        return now.value
t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    dic = defaultdict(node)
    for i in range(n):
        x, y, z = map(int, input().split())
        dic[x].value = x
        if y != -1:
            dic[x].left = dic[y]
            dic[y].lparent = dic[x]
            dic[y].value = y
        if z != -1:
            dic[x].right = dic[z]
            dic[z].rparent = dic[x]
            dic[z].value = z

    for i in range(m):
        s = list(map(int, input().split()))
        if s[0] == 1:
            a = dic[s[1]]
            b = dic[s[2]]
            if (a.lparent)and(b.lparent):
                a_parent = a.lparent
                b_parent = b.lparent
                a_parent.left = b
                b_parent.left = a
                a.lparent = b_parent
                b.lparent = a_parent
            elif (a.lparent)and(b.rparent):
                a_parent = a.lparent
                b_parent = b.rparent
                a_parent.left = b
                b_parent.right = a
                a.lparent = None
                a.rparent = b_parent
                b.rparent = None
                b.lparent = a_parent
            elif (a.rparent)and(b.lparent):
                a_parent = a.rparent
                b_parent = b.lparent
                a_parent.right = b
                b_parent.left = a
                a.rparent = None
                a.lparent = b_parent
                b.lparent = None
                b.rparent = a_parent
            elif (a.rparent)and(b.rparent):
                a_parent = a.rparent
                b_parent = b.rparent
                a_parent.right = b
                b_parent.right = a
                a.rparent = b_parent
                b.rparent = a_parent
        else:
            print(ask(dic[s[1]]))
        
        