n, m = map(int,input().split())
nei = [[] for i in range(n)]

def dfs(k):
    visited[k] = True
    this_visited[k] = True
    for i in nei[k]:
        if this_visited[i]:
            return True
        if not visited[i]:
            if dfs(i):
                return True
    this_visited[k] = False
for i in range(m):
    u, v = map(int,input().split())
    nei[u].append(v)

ans = False
for i in range(n):
    visited = [False]*n
    this_visited = [False]*n
    if dfs(i):
        ans = True
        #print(i)
        break

print(['No','Yes'][ans])
    