while True:
    n,p,m=map(int,input().split())
    if n==p==m==0:
        break
    s=[(i+1) for i in range(n)]
    ans=[]
    for i in range(n):
        ans.append(str(s[(p+m-2)%(n-i)]))
        del(s[(p+m-2)%(n-i)])
        p=(p+m-2)%(n-i)+1
    print(','.join(ans))