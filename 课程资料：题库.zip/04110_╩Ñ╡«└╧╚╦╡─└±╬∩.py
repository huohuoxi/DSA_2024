def take(p):
    return p[2]
n,w=map(int,input().split())
d=[]
s=0
for _ in range(n):
    d.append(list(map(int,input().split())))
    d[_].append(d[_][0]/d[_][1])
d.sort(key=take,reverse=True)
for _ in d:
    if _[1]<=w:
        w=w-_[1]
        s=s+_[0]
    else:
        s=s+w/_[1]*_[0]
        w=0
        break
print('%.1f'%s)