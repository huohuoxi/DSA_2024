m, n = map(int,input().split())
s = list(map(int,input().split()))
queue = []
count = 0
for i in s:
    if not (i in queue):
        count += 1
        if len(queue)<m:
            queue.append(i)
        else:
            queue.pop(0)
            queue.append(i)
print(count)