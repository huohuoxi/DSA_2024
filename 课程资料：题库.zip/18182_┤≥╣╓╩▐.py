N=int(input())
for _ in range(N):
    s=[]
    n,m,b=map(int,input().split())
    for i in range(n):
        s.append(list(map(int,input().split())))
        s[-1][1]=-s[-1][1]
    s.sort()
    for i in range(n):
        s[i][1]=-s[i][1]
    #print(s)
    cout_num=-1
    is_dead=False
    for i in range(n):
        if cout_num!=s[i][0]:
            cout=1
            cout_num=s[i][0]
        else:
            cout+=1
        if cout>m:
            continue
        else:
            b=b-s[i][1]
            if b<=0:
                print(s[i][0])
                is_dead=True
                break
    if is_dead==False:
        print('alive')