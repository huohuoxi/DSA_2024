import heapq
class Node:
    def __init__(self, value, freq):
        self.value = value
        self.freq = freq
        self.left = None
        self.right = None
        self.lfather = None
        self.rfather = None
        self.leaf = False
        self.code = ''
    def __lt__(self, other):
        if self.freq == other.freq:
            return self.value < other.value
        else:
            return self.freq < other.freq

def smaller_value(a, b):
    return [a, b][a > b]

def encode(node):
    if node.lfather:
        return(encode(node.lfather) + '0')
    elif node.rfather:
        return(encode(node.rfather) + '1')
    return ''
n = int(input())
s = []
for i in range(n):
    s.append(input().split())
node_list = [Node(k[0], int(k[1])) for k in s]
for k in node_list:
    k.leaf = True
nodes = set(node_list)
for i in range(n-1):
    smallest = heapq.nsmallest(2, nodes)
    new_node = Node(smaller_value(smallest[0].value, smallest[1].value), smallest[0].freq + smallest[1].freq)
    new_node.left = smallest[0]
    new_node.right = smallest[1]
    smallest[0].lfather = new_node
    smallest[1].rfather = new_node
    nodes.add(new_node)
    nodes.remove(smallest[0])
    nodes.remove(smallest[1])
    
root = nodes.pop()
for i in range(n):
    node_list[i].code += encode(node_list[i])
while 1:
    try:
        d = input()
    except EOFError:
        break
    ans = ''
    if d[0].isalpha():
        for k in d:
            for i in node_list:
                if i.value == k:
                    ans += i.code
                    break
        print(ans)
    else:
        now = root
        for k in d:
            #print(k)
            if k == '1':
                if now.right:
                    now = now.right
            elif k == '0':
                if now.left:
                    now = now.left
            if now.leaf:
                ans += now.value
                now = root
        print(ans)