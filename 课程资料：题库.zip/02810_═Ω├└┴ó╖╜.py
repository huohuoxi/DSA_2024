l=[]
s=[]
for _ in range(1,101):
    l.append(_**3)
l=set(l)

for i in range(2,100):
    for j in range(i,100):
        for k in range(j,100):
            if i**3+j**3+k**3 in l:
                s.append([round((i**3+j**3+k**3)**(1/3)),i,j,k])
s=sorted(s)

n=int(input())
for k in s:
    if (k[0]<=n)and(k[1]<=n)and(k[2]<=n)and(k[3]<=n):
        print('Cube = %d, Triple = (%d,%d,%d)' % (k[0],k[1],k[2],k[3]))