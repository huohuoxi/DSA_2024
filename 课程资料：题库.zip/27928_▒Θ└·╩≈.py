class Node:
    def __init__(self, value):
        self.child = []
        self.value = value
        self.root = True
def search(node):
    smaller = []
    bigger = []
    for i in node.child:
        if i.value < node.value:
            smaller.append(i)
        else:
            bigger.append(i)
    smaller = sorted(smaller,key = lambda x:x.value)
    bigger = sorted(bigger,key = lambda x:x.value)
    for k in smaller:
        search(k)
    print(node.value)
    for k in bigger:
        search(k)
n = int(input())
#nodes = [None]*10000000
nodess = []
biao = dict()
for i in range(n):
    s = list(map(int,input().split()))
    for k in s:
        if not(k in biao):
            biao[k] = Node(k)
    for j in range(1,len(s)):
        biao[s[0]].child.append(biao[s[j]])
        biao[s[j]].root = False
for i in biao:
    if biao[i].root:
        search(biao[i])
