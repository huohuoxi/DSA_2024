import math
import heapq
m, n, p = map(int,input().split())
mapp = []
for i in range(m):
    k = input().split()
    mapp.append(k)

def dijkstra(startx, starty, endx, endy):
    pq = []
    distance = [[math.inf]*n for _ in range(m)]
    distance[startx][starty] = 0
    heapq.heappush(pq, (0, [startx, starty]))
    visited = set()
    movex = [0, 1, 0, -1]
    movey = [1, 0, -1, 0]
    while pq:
        currentDist, currentVert = heapq.heappop(pq)    # 当一个顶点的最短路径确定后（也就是这个顶点
                                                        # 从优先队列中被弹出时），它的最短路径不会再改变。
        x = currentVert[0]
        y = currentVert[1]
        num = x * n + y
        if num in visited:
            continue
        visited.add(num)

        for i in range(4):
            newx = x + movex[i]
            newy = y + movey[i]
            if (0 <= newx <= m - 1)and(0 <= newy <= n - 1)and(mapp[newx][newy]!='#'):
                newDist = currentDist + abs(int(mapp[newx][newy]) - int(mapp[x][y]))
                if newDist < distance[newx][newy]:
                    distance[newx][newy] = newDist
                    heapq.heappush(pq, (newDist, [newx, newy]))
    if distance[endx][endy] == math.inf:
        return 'NO'
    else:
        return distance[endx][endy]

for i in range(p): 
    startx, starty, endx, endy = map(int,input().split())
    if mapp[startx][starty] == '#' or mapp[endx][endy] == '#':
        print('NO')
    else:
        print(dijkstra(startx, starty, endx, endy))