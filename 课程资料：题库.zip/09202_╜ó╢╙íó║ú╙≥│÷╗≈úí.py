from collections import deque
t = int(input())
for _ in range(t):
    n, m = map(int,input().split())
    flag = False
    mapp = [[] for i in range(n + 1)]
    visited = [0 for i in range(n + 1)]
    squeue = deque()
    def dfs(node, father):
        global flag
        for i in mapp[node]:
            if (visited[i] == 1) and (i != father):
                flag = True
                return True
            if visited[i] == 0:
                visited[i] = 1
                if dfs(i, node):
                    return True
        visited[node] = 2

    for i in range(m):
        x, y = map(int,input().split())
        mapp[x].append(y)

    for i in range(1, n + 1):
        if visited[i] == 0:
            dfs(i,-1)
        if flag == True:
            break
    print(['No','Yes'][flag])