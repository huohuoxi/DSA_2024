d=input()
while True:
    try:
        s=input()                
    except EOFError:
        break
    if len(s)!=len(d):
        print('NO')
        continue
    stack=[]
    p=0
    for i in range(len(d)):
        stack.append(d[i])
        while stack[-1]==s[p]:
            stack.pop()
            p+=1
            if (len(stack)==0)or(p==len(s)):
                break



    print(['NO','YES'][p==len(s)])