from collections import deque
aa, bb, c = map(int,input().split())
queue = deque()
visited = set()
def bfs(a, b, l):
    visited.add((0, 0))
    while 1:
        if a == c or b == c:
            print(len(l))
            for i in l:
                print(i)
            break
        
        if (aa, b) not in visited:
            queue.append(((aa, b), l+['FILL(1)']))
            visited.add((aa, b))
        if (a, bb) not in visited:
            queue.append(((a, bb), l+['FILL(2)']))
            visited.add((a, bb))
        if (0, b) not in visited:
            queue.append(((0, b), l+['DROP(1)']))
            visited.add((0, b))
        if (a, 0) not in visited:
            queue.append(((a, 0), l+['DROP(2)']))
            visited.add((a, 0))
        
        left = min(a + b, aa)
        right = max(0, a + b - aa)
        if (left, right) not in visited:
            queue.append(((left, right), l+['POUR(2,1)']))
            visited.add((left, right))
        
        left = max(0, a + b - bb)
        right = min(a + b, bb)
        if (left, right) not in visited:
            queue.append(((left, right), l+['POUR(1,2)']))
            visited.add((left, right))
        if queue:
            p = queue.popleft()
            (a, b), l = p
        else:
            print('impossible')
            break
    
bfs(0, 0, [])