from collections import deque

mapp = []
queue = deque()


def bfs(x,y):
    step = ((1,0),(-1,0),(0,1),(0,-1))
    num = 0
    while mapp[x][y] != 1:
        vis[x][y] = True
        for i in range(4):
            newx = x + step[i][0]
            newy = y + step[i][1]
            if (0 <= newx <= (m-1))and(0 <= newy <= (n-1))and(mapp[newx][newy]!=2)and(not vis[newx][newy]):
                queue.append((newx, newy, num + 1))
        if queue:
            x, y, num = queue.popleft()
        else:
            return 'NO'
    return num
m, n = map(int,input().split())
vis = [[False for i in range(n)] for j in range(m)]
for i in range(m):
    mapp.append(list(map(int,input().split())))

print(bfs(0, 0))
    