class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def evaluate(mid, post, node):
    node.value = post[-1]
    root = post[-1]
    sep = mid.find(root)
    left_mid = mid[:sep]
    left_post = post[:len(left_mid)]
    if left_mid:
        left_node = Node(None)
        evaluate(left_mid, left_post, left_node)
        node.left = left_node
    right_mid = mid[sep+1:]
    right_post = post[len(left_mid):-1]
    if right_mid:
        right_node = Node(None)
        evaluate(right_mid, right_post, right_node)
        node.right = right_node

def bfs(node):
    ans.append(node.value)
    if node.left:
        queue.append(node.left)
    if node.right:
        queue.append(node.right)
    if queue:
        bfs(queue.pop(0))

n = int(input())
for _ in range(n):
    mid = input()
    post = input()
    Root = Node(post[-1])
    evaluate(mid, post, Root)
    ans = []
    queue = []
    bfs(Root)
    print(''.join(ans))
