class Node:
    def __init__(self, value):
        self.left = None
        self.right = None
        self.value = value
        self.parent = None

def find(node, new):
    if not node.right:
        node.right = new
        new.parent = node
    else:
        find(node.parent, new)

def convert(node, num):
    global s
    new = Node(s[num])
    if node.value == '.':
        find(node.parent, new)
    else:
        if not node.left:
            node.left = new
            new.parent = node
        elif not node.right:
            node.right = new
            new.parent = node
        else:
            find(node.parent, new)
    if num + 1 <= len(s) - 1:
        convert(new, num + 1)
        
def mid(node):
    if node.left:
        mid(node.left)
    if node.value != '.':
        ans_mid.append(node.value)
    if node.right:
        mid(node.right)

def post(node):
    if node.left:
        post(node.left)
    if node.right:
        post(node.right)
    if node.value != '.':
        ans_post.append(node.value)
        
s = input()
root = Node(s[0])
convert(root, 1)
#print(root)
ans_mid = []
ans_post = []
mid(root)
post(root)
print(''.join(ans_mid))
print(''.join(ans_post))
