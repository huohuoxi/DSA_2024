def dfs(x,y):
    s[y][x] = '0'
    if (0 <= x+1 <= (m-1))and(0 <= y <= (n-1))and(s[y][x+1]!='0'):
        dfs(x+1, y)
    if (0 <= x-1 <= (m-1))and(0 <= y <= (n-1))and(s[y][x-1]!='0'):
        dfs(x-1, y)
    if (0 <= x <= (m-1))and(0 <= y+1 <= (n-1))and(s[y+1][x]!='0'):
        dfs(x, y+1)
    if (0 <= x <= (m-1))and(0 <= y-1 <= (n-1))and(s[y-1][x]!='0'):
        dfs(x, y-1)  
n, m = map(int,input().split())
s = []
ans = 0
for i in range(n):
    p = input()
    l = []
    for k in p:
        l.append(k)
    s.append(l)
    
for i in range(n):
    for j in range(m):
        if s[i][j] != '0':
            dfs(j,i)
            ans += 1
print(ans)