from collections import deque
def bfs():
    while queue:
        k = queue.popleft()
        if k%n == 0:
            break
        queue.append(k*10+1)
        queue.append(k*10)
    return k
while 1:
    n = int(input())
    if n == 0:
        break
    queue = deque([1])
    print(bfs())