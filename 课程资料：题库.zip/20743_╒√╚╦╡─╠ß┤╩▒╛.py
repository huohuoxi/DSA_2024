s = input()
stack = []
stack2 = []
for _ in s:
    
    if _ == ')':
        while True:
            p = stack.pop()
            if p == '(':
                stack += stack2
                stack2 = []
                break
            else:
                stack2.append(p)
    else:
        stack.append(_)
print(''.join(stack))