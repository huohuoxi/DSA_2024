def find(x):
    if parent[x] == x:
        return x
    else:
        parent[x] = find(parent[x])
        return find(parent[x])

def union(x, y):
    parent[find(x)] = find(y)

num = 0
while 1:
    num +=1
    n, m = map(int,input().split())
    if n == m == 0:
        break
    parent = [i for i in range(n+1)]
    for _ in range(m):
        a, b = map(int,input().split())
        union(a, b)
    group = [find(i) for i in range(n+1)]
    aset = set(group[1:])
    print('Case %d: %d'%(num, len(aset)))