def post_tree(alist):
    if not alist:
        return []
    root = alist[0]
    left = [k for k in alist if k < root]
    right = [k for k in alist if k > root]
    return post_tree(left) + post_tree(right) + [root]
n = int(input())
s = list(map(int,input().split()))
print(' '.join(map(str,post_tree(s))))