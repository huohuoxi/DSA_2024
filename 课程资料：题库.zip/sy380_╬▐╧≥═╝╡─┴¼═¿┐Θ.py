def dfs(k):
    visited[k] = 1
    for l in adj[k]:
        if not visited[l]:
            dfs(l)

n, m = map(int,input().split())
adj = [[] for _ in range(n)]
visited = [0]*n
for i in range(m):
    u, v = map(int,input().split())
    adj[u].append(v)
    adj[v].append(u)
num = 0
for i in range(n):
    if not visited[i]:
        dfs(i)
        num +=1

print(num)