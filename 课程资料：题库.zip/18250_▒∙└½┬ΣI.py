def find(x):
    if parent[x] == x:
        return x
    else:
        parent[x] = find(parent[x])
        return find(parent[x])

def union(x, y):
    parent[find(x)] = find(y)

while 1:
    try:
        n, m = map(int,input().split())
    except EOFError:
        break
    parent = [i for i in range(n+1)]
    for i in range(m):
        x, y = map(int,input().split())
        if parent[find(x)] == find(y) or parent[find(y)] == find(x):
            print('Yes')
        else:
            parent[find(y)] = find(x)
            print('No')
    parents = [find(i) for i in parent]
    k = set(parents[1:])
    print(len(k))
    l = list(k)
    l = sorted(l)
    print(' '.join(map(str,l)))
