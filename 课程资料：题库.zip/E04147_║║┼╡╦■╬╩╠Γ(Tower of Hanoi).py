def Hano(i,fr,to):
    if i>1:
        Hano(i-1,fr,3-fr-to)
    ko=tower[fr].pop()
    print('%d:%s->%s'%(ko,name[fr],name[to]))
    tower[to].append(ko)
    if i>1:
        Hano(i-1,3-fr-to,to)
    
n,a0,b0,c0=input().split()
name=[a0,b0,c0]
n=int(n)
tower=[[],[],[]]
tower[0]=[(i) for i in range(n,0,-1)]
n=int(n)
Hano(n,0,2)