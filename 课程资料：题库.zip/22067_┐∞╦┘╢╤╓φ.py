stack = []   # 存猪的栈
stack_sign = []  # 标记猪在不在轻猪的栈里
light = []  # 存一个轻猪的栈，只存比当前栈顶轻的猪，因为如果比栈顶的猪还重，还比它后进栈(先出栈)，永远用不上

while 1:
    try:
        s = input()
    except EOFError:
        break
    if s == 'pop':
        if stack:
            stack.pop()
            sign = stack_sign.pop()
            if sign:
                light.pop()
    elif s == 'min':
        if light:
            print(light[-1])
    else:
        n = int(s[5:])
        stack.append(n)
        if not light:
            stack_sign.append(True)
            light.append(n)
        elif n < light[-1]:
            stack_sign.append(True)
            light.append(n)
        else:
            stack_sign.append(False)
