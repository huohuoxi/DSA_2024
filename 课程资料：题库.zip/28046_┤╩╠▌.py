import itertools
class Vertex:
    def __init__(self, value):
        self.connectedTo = []
        self.value = value
        self.visited = False
        self.distance = None
        self.prev = None

def bfs(v):
    queue = []
    queue.append(v)
    v.visited = True
    v.distance = 0
    while queue:
        v = queue.pop(0)
        for i in v.connectedTo:
            if not i.visited:
                queue.append(i)
                i.visited = True
                i.prev = v
                i.distance = v.distance + 1

def reverse(v):
    ans.append(v.value)
    if v == vs[start]:
        return
    reverse(v.prev)

n = int(input())
s = []
buckets = {}
vs = {}
for i in range(n):
    l = input()
    v = Vertex(l)
    vs[l] = v
    for i, k in enumerate(l):
        bucket = l[:i] +'_'+ l[i + 1:]
        this_bucket = buckets.setdefault(bucket, set())
        this_bucket.add(v)
for i in buckets.values():
    for j in itertools.permutations(i, 2):
        j[0].connectedTo.append(j[1])
        j[1].connectedTo.append(j[0])
start, stop = input().split()

ans = []

bfs(vs[start])
if vs[stop].prev:
    reverse(vs[stop])
    ans = list(reversed(ans))
    print(' '.join(ans))
else:
    print('NO')


