s = input()
ans = []
for i in range(len(s)):
    p = s[:(i+1)]
    ans.append(['0','1'][(int(p, 2)%5)==0])
print(''.join(ans))