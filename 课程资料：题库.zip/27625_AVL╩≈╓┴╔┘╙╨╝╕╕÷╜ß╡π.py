n = int(input())
ans = [0]*40
ans[0] = 1
ans[1] = 2
for i in range(2,40):
    ans[i] = ans[i-1] + ans[i-2] +1
for i in range(40):
    if ans[i]>n:
        print(i)
        break