class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def evaluate(mid, pre, node):
    node.value = pre[0]
    root = pre[0]
    sep = mid.find(root)
    left_mid = mid[:sep]
    left_pre = pre[1:len(left_mid)+1]
    if left_mid:
        left_node = Node(None)
        evaluate(left_mid, left_pre, left_node)
        node.left = left_node
    right_mid = mid[sep+1:]
    right_pre = pre[len(left_mid)+1:]
    if right_mid:
        right_node = Node(None)
        evaluate(right_mid, right_pre, right_node)
        node.right = right_node

def output(node):
    if node.left:
        output(node.left)
    if node.right:
        output(node.right)
    ans.append(node.value)

while 1:
    try:
        pre = input()
        mid = input()
        Root = Node(pre[0])
        evaluate(mid, pre, Root)
        ans = []
        output(Root)
        print(''.join(ans))
    except EOFError:
        break
