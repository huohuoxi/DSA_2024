def find(x):
    if parent[x] == x:
        return x
    else:
        return find(parent[x])

def union(x, y):
    parent[find(x)] = find(y)

n, m = map(int,input().split())
parent = [i for i in range(n+1)]
for _ in range(m):
    a, b = map(int,input().split())
    union(a, b)
group = set([find(x) for x in range(1,n+1)])
print(len(group))
