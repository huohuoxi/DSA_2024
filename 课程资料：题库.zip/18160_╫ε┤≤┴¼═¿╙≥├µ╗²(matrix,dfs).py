maxstep = 0
def dfs(x, y):
    global maxstep
    maxstep += 1
    v[x][y] = True
    movex = [-1, 0, 1, -1, 1, -1, 0, 1]
    movey = [1, 1, 1, 0, 0, -1, -1, -1]
    for i in range(8):
        if (0 <= x + movex[i] <= n-1)and(0 <= y + movey[i] <= m-1):
            if not(v[x + movex[i]][y + movey[i]])and(s[x + movex[i]][y + movey[i]] == 'W'):
                dfs(x + movex[i], y + movey[i])
t = int(input())
for ii in range(t):
    n, m = map(int,input().split())
    s = [0]*n
    for i in range(n):
        s[i] = list(input())
    max_maxstep = 0
    v = [[False]*m for _ in range(n)]
    for i in range(n):
        for j in range(m):
            if s[i][j] == 'W' and not(v[i][j]):
                maxstep = 0
                dfs(i, j)
                max_maxstep = max(max_maxstep, maxstep)
    print(max_maxstep)