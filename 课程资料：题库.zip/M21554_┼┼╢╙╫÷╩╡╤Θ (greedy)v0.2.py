def take(p):
    return p[1]
n=int(input())
s=list(map(int,input().split()))
l=[]
for i in range(n):
    l.append([i+1,s[i]])
l=sorted(l,key=take)
time=0
ans=[]
for i in range(n):
    time=time+l[i][1]*(n-i-1)
    ans.append(str(l[i][0]))
time=time/n
print(' '.join(ans))
print('%.2f'%time)