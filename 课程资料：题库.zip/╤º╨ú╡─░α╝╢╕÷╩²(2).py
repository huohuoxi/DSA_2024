def find(x):
    if parent[x] == x:
        return x
    else:
        return find(parent[x])

def union(x, y):
    parent[find(x)] = find(y)

n, m = map(int,input().split())
parent = [i for i in range(n+1)]
count = [0]*(n+1)
for _ in range(m):
    a, b = map(int,input().split())
    union(a, b)
group = [find(x) for x in range(1,n+1)]
aset = set(group)
print(len(aset))
for i in range(n):
    count[group[i]] += 1
count = sorted(count[1:], reverse=True)
ans = []
for i in range(n):
    if count[i] != 0:
        ans.append(count[i])
print(' '.join(map(str,ans)))