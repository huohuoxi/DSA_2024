n, m = map(int,input().split())
degree_in = [0]*n
degree_out = [0]*n
for i in range(m):
    u, v = map(int,input().split())
    degree_in[u]+=1
    degree_out[v]+=1
for i in range(n):
    print(degree_out[i], degree_in[i])