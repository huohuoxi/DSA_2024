from collections import deque
t = int(input())
for _ in range(t):
    n = int(input())
    a = list(map(int,input().split()))
    a = deque(a)
    b = list(map(int,input().split()))
    i = 0
    count = 0
    for i in range(n):
        while a[i] < b[i]:
            a.popleft()
            a.append(100)
            count += 1
    print(count)