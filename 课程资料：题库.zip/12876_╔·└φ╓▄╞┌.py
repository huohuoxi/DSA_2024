maxi=22253
n=0
while True:
    n=n+1
    p,e,j,d=map(int,input().split())
    if p==e==j==d==-1:
        break
    s=[0]*maxi
    for i in range(p,maxi,23):
        s[i]=s[i]+1
    for i in range(e,maxi,28):
        s[i]=s[i]+1
    for i in range(j,maxi,33):
        s[i]=s[i]+1
    for i in range(d+1,maxi):
        if s[i]==3:
            print('Case %d: the next triple peak occurs in %d days.' % (n,i-d))
            break