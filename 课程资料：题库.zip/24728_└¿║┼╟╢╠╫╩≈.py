class Node:
    def __init__(self, value):
        self.child = []
        self.value = value


def preorder(node):
    for k in node.child:
        output_pre.append(k.value)
        preorder(k)


def postorder(node):
    for k in node.child:
        postorder(k)
        output_post.append(k.value)


s = input()
fathers = []
for k in s:
    if k == '(':
        fathers.append(node)
    elif k == ')':
        if fathers:
            node = fathers.pop()
    elif k.isalpha():
        node = Node(k)
        if fathers:
            fathers[-1].child.append(node)   
output_pre = [node.value]
preorder(node)
output_post = []
postorder(node)
output_post.append(node.value)
print(''.join(output_pre))
print(''.join(output_post))