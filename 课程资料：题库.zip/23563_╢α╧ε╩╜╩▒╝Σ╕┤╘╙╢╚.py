s=input().split('+')
d=[]
for i in range(len(s)):
    if s[i][0]=='0':
        del(s[i])
for i in s:
    d.append(int(i.split('^')[-1]))
d.sort()
print('n^'+str(d[-1]))