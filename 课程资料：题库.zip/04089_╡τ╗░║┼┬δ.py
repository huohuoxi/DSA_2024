import collections

class Node:
    def __init__(self):
        self.child = collections.defaultdict(Node)
        self.leaf = True
    def addchild(self, name):
        newnode = Node()
        self.child[name] = newnode
        node_list.append(newnode)

def convert(l, node):
    if not l:
        return
    if not(l[0] in node.child):
        node.addchild(l[0])
        node.leaf = False
    convert(l[1:], node.child[l[0]])
t = int(input())
for ii in range(t):
    n = int(input())
    root = Node()
    node_list = []
    count = 0
    for i in range(n):
        s = list(input())
        convert(s, root)
    for k in node_list:
        if k.leaf:
            count += 1
    if count == n:
        print('YES')
    else:
        print('NO')