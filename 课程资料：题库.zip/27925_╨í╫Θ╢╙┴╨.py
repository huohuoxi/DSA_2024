t = int(input())
squeue = []
squeue_value = []
dic = dict()
for i in range(t):
    s = input().split()
    for j in s:
        dic[j] = i
while 1:
    m = input().split()
    if m[0] == 'STOP':
        break
    if m[0] == 'ENQUEUE':
        try:
            ind = squeue_value.index(dic[m[1]])
            squeue[ind].append(m[1])
        except:
            squeue_value.append(dic[m[1]])
            squeue.append([m[1]])
    else:
        if len(squeue[0])>1:
            print(squeue[0].pop(0))
        else:
            print(squeue.pop(0)[0])
            squeue_value.pop(0)

        
            