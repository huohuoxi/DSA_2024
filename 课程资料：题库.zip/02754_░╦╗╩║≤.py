def dfs(l, count):
    if count == 8:
        ll = [k+1 for k in l]
        ans.append(''.join(map(str,ll)))
    diag1 = []
    diag2 = []
    for i, k in enumerate(l):
        diag1.append(i - k)
        diag2.append(i + k)
    for i in range(8):
        if (not i in l)and(not (count - i) in diag1)and(not (count + i) in diag2):
            dfs(l+[i], count + 1)

ans = []
dfs([], 0)
n = int(input())
for i in range(n):
    p = int(input())
    print(ans[p-1])