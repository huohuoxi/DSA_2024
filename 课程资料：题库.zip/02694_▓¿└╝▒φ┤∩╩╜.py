s=input().split()
stack=[]
for i in reversed(s):
    if i in ["+","-","*","/"]:
        a=stack.pop()
        b=stack.pop()
        stack.append(eval(str(a)+i+str(b)))
    else:
        stack.append(i)
print('%.6f'%stack[0])