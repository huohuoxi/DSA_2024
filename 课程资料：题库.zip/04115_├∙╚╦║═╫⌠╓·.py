from collections import deque
m, n, t = map(int,input().split())
mapp = []
#visited = [[False]*n for _ in range(m)]
visit =[[[False]*n for _ in range(m)] for i in range(t + 1)]
queue = deque()

def bfs(x, y, endx, endy):
    queue.append([x, y, 0, t])
    movex = [0, 1, 0, -1]
    movey = [1, 0, -1, 0]
    cha = t
    visit[t][x][y] = True
    success = False
    while queue:
        k = queue.popleft()
        x = k[0]
        y = k[1]
        time = k[2]
        cha = k[3]
        if x == endx and y == endy:
            success = True
            break
        #visited[x][y] = True
        for i in range(4):
            if (0 <= x + movex[i] <= m - 1)and(0 <= y + movey[i] <= n - 1):
                if mapp[x + movex[i]][y + movey[i]] == '#':
                    if (cha > 0) and (not visit[cha-1][x + movex[i]][y + movey[i]]):
                        queue.append([x + movex[i], y + movey[i], time + 1, cha - 1])
                        visit[cha-1][x + movex[i]][y + movey[i]] = True
                else:
                    if (not visit[cha][x + movex[i]][y + movey[i]]):
                        queue.append([x + movex[i], y + movey[i], time + 1, cha])
                        visit[cha][x + movex[i]][y + movey[i]] = True
    if success:
        return time
    else:
        return -1



for i in range(m):
    k = input()
    mapp.append(k)
    temp = k.find('@')
    if temp != -1:
        starty = temp
        startx = i
    temp = k.find('+')
    if temp != -1:
        endy = temp
        endx = i
#print(startx,starty, endx, endy)
print(bfs(startx, starty, endx, endy))