import heapq
import sys
import copy

class Vertex:
    def __init__(self, key):
        self.id = key
        self.connectedTo = {}
        self.distance = sys.maxsize
        self.pred = None

    def addNeighbor(self, nbr, weight=0):
        self.connectedTo[nbr] = weight

    def getConnections(self):
        return self.connectedTo.keys()

    def getWeight(self, nbr):
        return self.connectedTo[nbr]

    def __lt__(self, other):
        return self.distance < other.distance

class Graph:
    def __init__(self):
        self.vertList = {}
        self.numVertices = 0

    def addVertex(self, key):
        newVertex = Vertex(key)
        self.vertList[key] = newVertex
        self.numVertices += 1
        return newVertex

    def getVertex(self, n):
        return self.vertList.get(n)

    def addEdge(self, f, t, cost=0):
        if f not in self.vertList:
            self.addVertex(f)
        if t not in self.vertList:
            self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t], cost)

def dijkstra(graph, start):
    pq = []
    start.distance = 0
    heapq.heappush(pq, (0, start))
    visited = set()

    while pq:
        currentDist, currentVert = heapq.heappop(pq)    # 当一个顶点的最短路径确定后（也就是这个顶点
                                                        # 从优先队列中被弹出时），它的最短路径不会再改变。
        if currentVert in visited:
            continue
        visited.add(currentVert)

        for nextVert in currentVert.getConnections():
            newDist = currentDist + currentVert.getWeight(nextVert)
            if newDist < nextVert.distance:
                nextVert.distance = newDist
                nextVert.pred = currentVert
                heapq.heappush(pq, (newDist, nextVert))

p = int(input())
dic = {}
g = Graph()
for i in range(p):
    name = input()
q = int(input())
for i in range(q):
    a, b, dis = input().split()
    g.addEdge(a, b, int(dis))
    g.addEdge(b, a, int(dis))

r = int(input())
origin = copy.deepcopy(g)
def printPath(vert):
    if vert.pred:
        printPath(vert.pred)
        print(f"->({str(vert.connectedTo[vert.pred])})->", end="")
    print(vert.id, end="")
for i in range(r):
    c, d = input().split()
    g = copy.deepcopy(origin)
    if c == d:
        print(c)
    else:
        dijkstra(g, g.getVertex(c))
        vertex = g.getVertex(d)
        printPath(vertex)
        print("")