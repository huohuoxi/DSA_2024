n, m = map(int,input().split())
c = [[] for _ in range(n)]
for i in range(m):
    u, v = map(int,input().split())
    c[u].append(v)
    c[v].append(u)
visited = [0 for _ in range(n)]
done = [0 for _ in range(n)]
has_loop = False
def dfs(num, father):
    global has_loop
    visited[num] = 1
    for i in c[num]:
        if done[num] == 0 and visited[i] and i != father:
            has_loop = True
        if not visited[i]:
            dfs(i, num)
    done[num] = 1
            
dfs(0, -1)
print(f"connected:{['no', 'yes'][sum(visited) == n]}")
print(f"loop:{['no', 'yes'][has_loop]}")