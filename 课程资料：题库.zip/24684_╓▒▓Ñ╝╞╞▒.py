s=list(map(int,input().split()))
p=[0]*100001
out=[]
for i in s:
    p[i]+=1
max=0
for i in p:
    if i>max:
        max=i
for i in range(100001):
    if p[i]==max:
        out.append(i)
print(' '.join(map(str,out)))
