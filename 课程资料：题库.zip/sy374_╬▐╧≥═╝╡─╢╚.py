n, m = map(int,input().split())
degree = [0]*n
for i in range(m):
    u, v = map(int,input().split())
    degree[u]+=1
    degree[v]+=1
print(' '.join(map(str,degree)))