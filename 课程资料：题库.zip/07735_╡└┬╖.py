import heapq

def dijkstra(N, G, start):
    pq = [(0, start, k)]  # 使用优先队列，存储节点的最短距离
    while pq:
        d, node, currentfee = heapq.heappop(pq)  # 弹出当前最短距离的节点
        if node == n:
            return d
        for neighbor, weight, fee in G[node]:  # 遍历当前节点的所有邻居节点
            new_dist = d + weight  # 计算经当前节点到达邻居节点的距离
            newFee = currentfee - fee 
            if newFee >= 0:  
                heapq.heappush(pq, (new_dist, neighbor, newFee))  # 将邻居节点加入优先队列
    return -1

k = int(input())
n = int(input())
r = int(input())
G = [[] for _ in range(n + 1)]
for i in range(r):
    s, d, l, t = map(int,input().split())
    G[s].append((d, l, t))
print(dijkstra(n, G, 1))