k=int(input())
s=list(map(int,input().split()))
dp=[1 for i in range(k)]
for i in range(k):
    for j in range(i):
        if s[i]<=s[j]:
            dp[i]=max(dp[j]+1,dp[i])
maxi=max(dp)
print(maxi)