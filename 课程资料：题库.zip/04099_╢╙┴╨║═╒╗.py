m=int(input())
for i in range(m):
    queue=[]
    stack=[]
    n=int(input())
    error_queue=False
    error_stack=False
    for j in range(n):
        s=input()
        if s[:4]=='push':
            k=int(s[5:])
            queue.append(k)
            stack.append(k)
        else:
            try:
                queue.pop(0)
            except:
                error_queue=True
            try:
                stack.pop()
            except:
                error_stack=True
    if not(error_queue):
        print(' '.join(map(str,queue)))
    else:
        print('error')
    if not(error_stack):
        print(' '.join(map(str,stack)))
    else:
        print('error')