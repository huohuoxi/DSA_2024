import heapq
n = int(input())
heap = list(map(int,input().split()))
heapq.heapify(heap)
cost = 0
for i in range(n-1):
    a = heapq.heappop(heap)
    b = heapq.heappop(heap)
    c = a + b
    cost += c
    heapq.heappush(heap, c)
print(cost)
